프리즘판 개정 파일

교재: prism-shopping-shortform-v4.pdf (70쪽), Word·Markdown 수정본
상세 과제: prism-30-day-guide-v4.pdf (31쪽), 수정본
엑셀: prism-30-day-workbook-v4.xlsx (DAY01~30, 진행표, 게시150행, 소스·카페 기록)
판매글: prism-challenge-sales-v4.md / .docx
운영안: prism-operator-v4.pdf / .docx / .md
카페 인증: prism-cafe-template-v4.txt
대본 검토표: prism-source-review-v4.md

2026년 10월 14일 개정. 제공된 10월 12일 프리즘 라이브 대본의 기능과 작업 흐름을 반영했다. 실제 프로그램 실행·최신 플랫폼 정책·성능 수치를 검증 완료한 판은 아니다.
유튜브·클립은 대본의 현재 자동 발행 지원, 나머지 3곳은 직접 게시 기본 흐름으로 나눴다.
판매글은 10명·15만원·30일 모집용이다. 프로그램·AI 비용 포함, 시작일·교육·피드백·신청·결제·환불은 실제 운영 조건으로 확정한다.
원문 파일 자체는 공개 패키지에 넣지 않았다.
