한다체 상세 실습판

shopping-shortform-v3.pdf — 교재 64쪽
shopping-shortform-v3.docx / .md — 수정 원고
30-day-detailed-guide-v3.pdf — 사용법 1쪽 + 하루 1쪽, 총 31쪽 과제집
30-day-detailed-workbook-v3.xlsx — 진행표와 DAY01~DAY30 상세 시트, 게시·소스·카페 기록
30-day-detailed-tasks-v3.csv — 모든 상세 과제를 한 표로 가져오기
challenge-sales-copy-v3.md / .docx — 10명·15만원 챌린지 판매글
sales-publication-check.txt — 판매글 게시 전 확정 사항

교재 설명을 한다·확인한다·기록한다체로 바꿨다. 권리자에게 보내는 요청 메시지 예시는 상대에게 직접 보내는 문구이므로 정중한 문체를 유지했다.
Shorts Studio의 실제 배포 화면을 시험한 것은 아니며 현재 가능한 제한 제작 경로와 개발 중인 기능을 구분했다. 최신 정책을 검증 완료한 판은 아니다.
